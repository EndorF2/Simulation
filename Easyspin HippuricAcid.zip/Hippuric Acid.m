clear, clf,clc                     % Irradiated hippuric acid powder
Sys.g  = 2.0028; 
Sys.Nucs = '14N,1H,1H';
aN = [-7.58 -8.47 -9.44];          % 14N hfc principal values (MHz)
qN = [-0.843 0.582 0.261];         % 14N nqc principal values (MHz)
aH1 = [-24.22 -48.70 -81.20];      % H1 principal hfc values (MHz)
aH2 = [-25.46 -48.98 -79.06];      % H2 principal hfc values (MHz)
noll=[0 0 0];
Sys.A = [aN;aH1;aH2]; 
VaN=[-0.1990    1.1209    1.6005]; % 14N hfc Euler angles
VqN=[-0.1731    1.1435    1.5145]; % 14N nqc Euler angles
VaN=-flip(VaN);                    % See EasySpin documentation
VqN=-flip(VqN);                    % -"-
VaH1=[1.2027    1.4427    2.6315]; % H1 hfc Euler angles
VaH2=[1.9219    1.3348    0.3681]; % H2 hfc Euler angles
VaH1=-flip(VaH1);                  % See EasySpin documentation
VaH2=-flip(VaH2);                  % -"-
Sys.AFrame = [VaN;VaH1;VaH2]; 
Sys.Q = [qN;noll;noll];  % (MHz)
Sys.QFrame = [VqN;noll;noll];
Sys.lwEndor = [0 0.35];  % (MHz)
Exp.Range = [1 7];       % (MHz)
Exp.Field=341.53;        % (mT)
Exp.mwFreq = 9.57367;    % (GHz)
Exp.Harmonic = 1;
Opt.nKnots = 81;
Opt.Method = 'matrix'; 
Opt.Nuclei = 1;          % 14N spectrum 
Exp.ExciteWidth = 2.8;   % MHz
Opt.Enhancement = 'on';
[f, signal]=salt(Sys,Exp,Opt);
plot(f,signal);
xlim([min(f) max(f)]); ylim([min(signal),max(signal)]);
xlabel('Frequency (MHz)'); ylabel('Intensity')
title(sprintf('Hippuric acid'));
