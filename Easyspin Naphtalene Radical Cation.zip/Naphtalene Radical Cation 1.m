clear, clf, clc;% Naphthalene cation
t0=clock;
Sys.g  = [2.0028 2.0024 2.0025]; 
Sys.Nucs = '1H,1H,1H,1H,1H,1H,1H,1H';
%Sys.Nucs = '1H,1H,1H,1H';
a1 = [-24.1 -7.9 -17.4];  % a1 principal hfc values (MHz)
a2 = [-7.6 0.3 -6.7];     % a2 principal hfc values (MHz)
Sys.A = [a1;a1;a1;a1;a2;a2;a2;a2];
%Sys.A = [a1;a1;a1;a1];
V1=[0 0 0];         % a1 Euler angles
V21=[1.2693  0  0]; % a21 Euler angles
V22=[1.8723  0  0]; % a22 Euler angles
V21=-flip(V21);     % See EasySpin documentation
V22=-flip(V22);     % See EasySpin documentation
Sys.AFrame = [V1;V1;V1;V1;V21;V21;V22;V22];
%Sys.AFrame = [V1;V1;V1;V1];
Sys.lwEndor = 1.0;      % (MHz)
Exp.Range = [0 30];     % (MHz)
Exp.Field = 338.94;     % (mT)
Exp.mwFreq = 9.5;       % (GHz)
Exp.Harmonic = 1;   
Exp.ExciteWidth = 2.0;  % MHz
Exp.ExciteWidth = 200; % MHz
Opt.Enhancement = 'on';
[F_0, signal]=salt(Sys,Exp,Opt);
signal=signal/(max(signal)-min(signal));
plot(F_0,signal);
xlim([min(F_0) max(F_0)]); ylim([min(signal),max(signal)]);
xlabel('MHz'); ylabel('Intensity')
title(sprintf('Naphthalene cation'));
fprintf('time = %10.1f seconds\n',etime(clock,t0));

