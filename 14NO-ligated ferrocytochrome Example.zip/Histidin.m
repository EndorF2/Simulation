Ahis = [16.5 16.1 19.3];        % Histidine 14N hfc principal values[MHz)
Qhis = [0.45 0.67 -1.12];       % Histidine nqc principal values (MHz)
Ano = [30.56 30.56 59.90];      % 14NO principal hfc values (MHz)
Qno = [1.03 -0.51 -0.52];       % 14NO principal nqc values (MHz)
Vhis = [0 0 0];                 % Histidine 14N  hfc Euler angles (rad)
Vno = -[-1.5708 0.3054 1.5708]; % 14NO hfc Euler angles (rad)
Sys.g  = [2.082 1.979 2.008];   % g-tensor principal values 
Sys.Nucs = '14N,14N';
Sys.A = [Ahis; Ano];            % 14N hfc principal values (MHz)
Sys.AFrame = [Vhis;Vno];        % 14N hfc Euler angles (rad)
Sys.Q = [Qhis;Qno];             % 14N nqc principal values (MHz (MHz)
Sys.lwEndor = [0 0.6];          % Lorentzian line width (MHz)
Exp.Range = [4 24];             % Frequency sweep range (MHz)
Exp.Field = 320.294;            % Bobs value(mT)
Exp.mwFreq = 9.32;              % Microwave frequency (GHz)
Exp.ExciteWidth = 16.8;         % Excitation width (MHz)
Opt.Method = 'matrix';          % Matrix diagonalization
Opt.Enhancement = 'on';         % Hyperfine enhancement
[freq, signal]=salt(Sys,Exp,Opt);
plot(freq,signal); xlabel('Frequency (MHz)'); ylabel('Intensity')
title(sprintf('14NO-ligated ferrocytochrome c heme'));
