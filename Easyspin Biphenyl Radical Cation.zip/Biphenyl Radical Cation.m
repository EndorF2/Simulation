clear, clf,clc;% Biphenyl cation
Sys.g  = [2.0030 2.0021 2.0022]; 
Sys.Nucs = '1H,1H,1H,1H,1H,1H';
aHp = [-26.9 -7.9 -18.3];  % para-H principal hfc values (MHz)
aHo = [-12.2 -4.4 -10.0];  % ortho-H principal hfc values (MHz)
Sys.A = [aHp;aHp;aHo;aHo;aHo;aHo];
V0=[0 0 0];         % para H Euler angles
VaHo1=[1.9574 0 0]; % ortho H1 Euler angles
VaHo2=[1.1841 0 0]; % ortho H2 Euler angles
VaHo1=-flip(VaHo1); % See EasySpin documntation
VaHo2=-flip(VaHo2); % -"-
Sys.AFrame = [V0;V0;VaHo1;VaHo1;VaHo2;VaHo2];
Sys.lwEndor = 0.30;    % (MHz)
Exp.Range = [3 30];    % (MHz)
Exp.Field = 341.40;    % (mT)
Exp.mwFreq = 9.5670;   % (GHz)
Exp.Harmonic = 1;      % 1st derivative
Exp.nPoints = 2048;
Exp.ExciteWidth = 2.8; % MHz
Opt.Method = 'matrix';
Opt.Enhancement = 'on';
[F_0, signal]=salt(Sys,Exp,Opt);
signal=signal/(max(signal)-min(signal));
plot(F_0,signal);
xlim([min(F_0) max(F_0)]); ylim([min(signal),max(signal)]);
xlabel('MHz'); ylabel('Intensity')
title(sprintf('Biphenyl cation'));
