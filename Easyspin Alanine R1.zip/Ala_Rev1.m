clear, clf,clc                     % Alanine R1 radical
Sys.g  = 2.0033;                   % Exp: g=[2.0041 2.0034 2.0024]; 
Sys.Nucs = '1H,1H,1H,1H,1H';
A1 = [-87.8 -52.5 -27.8];          % H-alfa principal hfc values (MHz)
A2 = [74.7 67.6 67.3];             % H-beta principal hfc values (MHz)
A3 = [5.1 -2.1 -2.6];              % H-gamma principal hfc values (MHz
Sys.A = [A1;A2;A2;A2;A3];
V1 =[-0.6420   1.3484    0.5622];  % H-alfa Euler angles
V2 =[0.0574    2.2199    1.9514];  % H-beta Euler angles
V3 =[2.9103    2.5350   -1.6269];  % H-gamma Euler angles
Sys.AFrame =  [V1;V2;V2;V2;V3];    
Sys.lwEndor =.3;                   % (MHz)
Exp.Range = [12 60];               % (MHz)
Exp.Field = 340.7;                 % (mT)
Exp.mwFreq = 9.5527;               % (GHz)
Exp.Harmonic = 1;                  
Opt.Method = 'matrix';             
Exp.ExciteWidth = inf;             % MHz
Opt.Enhancement = 'on';
[F_0, signal]=salt(Sys,Exp,Opt);
plot(F_0,signal);
xlim([min(F_0) max(F_0)]); ylim([min(signal),max(signal)]);
xlabel('MHz'); ylabel('Intensity')
title(sprintf('Alanine R1'));
