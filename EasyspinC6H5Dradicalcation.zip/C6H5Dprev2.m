clear, clf,clc;                 % C6H5D katjon, PCCP, 1:4967-4974 (1999)
Sys.g  = [2.0029 2.0029 2.0023]; 
Sys.Nucs = '1H,1H,2H,1H,1H,1H'; %Alt. II:%Sys.Nucs = '2H,1H,1H,1H,1H,1H';
A1 =   [-38.2480  -10.8080  -25.8440];
A2 =   [-8.1480     0        -8.1480];
D1=A1*0.153; % D atom, ring pos 1 principal hfc values (MHz)
D2=A2*0.153; % D atom, ring pos 2 principal hfc values (MHz)
H1 = A1;     % H atom, ring pos 4 principal hfc values (MHz)
H4 = A1;     % H atom, ring pos 4 principal hfc values (MHz)
H2 = D2;     % H atom, ring pos 2 principal hfc values (MHz)
H3 = A2;     % H atom, ring pos 3 principal hfc values (MHz)
H5 = A2;     % H atom, ring pos 5 principal hfc values (MHz)
H6 = A2;     % H atom, ring pos 6 principal hfc values (MHz)
Sys.A = [H1;H4;D2;H3;H5;H6]; %Alt. II:%Sys.A = [D1;H4;H2;H3;H5;H6];
V1=[0 0 0];                        % H1 Euler angles
V2 = -180/pi*flip([-67.8 0 0]);    % H2 Euler angles
V3 = -180/pi*flip([-112.2 0 0]);   % H3 Euler angles
V4=V1;                             % H4 Euler angles
V5=V2;                             % A5 Euler angles
V6=V3;                             % A6 Euler angles
Sys.AFrame = [V1;V4;V2;V3;V5;V6];
Sys.lwEndor = 0.6;                 % (MHz) 
Exp.Range = [0 36];                % (MHz)
Exp.Field = 338.92;                % (mT) 
Exp.mwFreq = 9.5;                  % (GHz)
Exp.Harmonic = 1;    
Opt.Method = 'matrix';    
Exp.ExciteWidth = 100;             % (MHz)
Opt.Enhancement = 'on';
[F_0, signal]=salt(Sys,Exp,Opt);
plot(F_0,signal);
xlim([min(F_0) max(F_0)]); ylim([min(signal),max(signal)]);
xlabel('MHz'); ylabel('Intensity')
title(sprintf('C6H5D+'));